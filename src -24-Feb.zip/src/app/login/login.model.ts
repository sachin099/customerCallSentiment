export class LoginRequest {
    userId:string ="";
    password:string ="";
}